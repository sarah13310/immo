<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Melanie extends BaseController
{
    public function index()
    {
        //
    }
}
