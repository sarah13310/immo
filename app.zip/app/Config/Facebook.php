<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Facebook extends BaseConfig
{
    public $app_id = '543016527981563';
    public $app_secret = '37e2800198199949e26df8f18393fc35';
    public $default_graph_version = 'v2.10';
}